from dataclasses import dataclass


@dataclass
class BalanceApiResponse:
    credits: int
